//
//  WZCBluetooth.h
//  WZCBluetooth
//
//  Created by pengbingxiang on 2017/8/21.
//  Copyright © 2017年 yiweixing. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BluetoothManager.h"

#import "WBTError.h"

//! Project version number for WZCBluetooth.
FOUNDATION_EXPORT double WZCBluetoothVersionNumber;

//! Project version string for WZCBluetooth.
FOUNDATION_EXPORT const unsigned char WZCBluetoothVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WZCBluetooth/PublicHeader.h>


