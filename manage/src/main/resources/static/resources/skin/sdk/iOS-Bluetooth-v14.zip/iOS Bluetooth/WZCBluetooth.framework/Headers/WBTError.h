//
//  WBTError.h
//  BluetoothDemo
//
//  Created by pengbingxiang on 2018/1/16.
//  Copyright © 2018年 yiweixing. All rights reserved.
//

#import <Foundation/Foundation.h>

@class NSDictionary<KeyType, ObjectType>, NSString;

typedef NSString *WBTErrorDomain;

// 蓝牙配对失败的错误域
FOUNDATION_EXPORT WBTErrorDomain _Nullable const FailurePairDomain;

typedef NSString *WBTErrorUserInfoKey;

// 详细描述键
FOUNDATION_EXPORT WBTErrorUserInfoKey _Nullable const WBTDescriptionKey;

// 失败原因键
FOUNDATION_EXPORT WBTErrorUserInfoKey _Nullable const WBTFailureReasonKey;

// 恢复建议键
FOUNDATION_EXPORT WBTErrorUserInfoKey _Nullable const WBTSuggestionKey;

@interface WBTError : NSObject<NSCopying>

/** 错误域 */
@property (nonatomic, copy, readonly) WBTErrorDomain _Nullable errorDomain;
/** YWX
 * code 错误码
 * 10001   ---   连接蓝牙设备失败
 * 10002   ---   没有扫描到蓝牙设备的服务（一般不会出现）
 * 10003   ---   没有扫描到蓝牙设备的特征（一般不会出现）
 * 20000   ---   连接超时
 */
@property (nonatomic, assign) NSInteger code;
/** 错误信息 */
@property (nonatomic, strong, readonly) NSDictionary<WBTErrorUserInfoKey, id> * _Nullable userInfo;

- (instancetype _Nullable )initWithDomain:(WBTErrorDomain _Nullable )domain code:(NSInteger)code userInfo:(nullable NSDictionary<WBTErrorUserInfoKey, id> *)dict;

@end

