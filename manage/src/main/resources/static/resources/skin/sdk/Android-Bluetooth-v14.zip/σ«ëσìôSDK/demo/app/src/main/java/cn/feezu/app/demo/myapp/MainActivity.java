package cn.feezu.app.demo.myapp;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.databinding.Observable;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import cn.feezu.ble_control.BLEPresenter;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private MainViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);

        ViewDataBinding viewDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        viewModel = new MainViewModel(this);
        viewDataBinding.setVariable(cn.feezu.app.demo.myapp.BR.viewModel, viewModel);

        viewModel.showPickCarDialog.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                if (viewModel.showPickCarDialog.get()) {
                    setAndShowDialDialog(1);
                }
            }
        });

        viewModel.showReturnCarDialog.addOnPropertyChangedCallback(new Observable.OnPropertyChangedCallback() {
            @Override
            public void onPropertyChanged(Observable sender, int propertyId) {
                if (viewModel.showReturnCarDialog.get()) {
                    setAndShowDialDialog(2);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        viewModel.resume();
    }

    @Override
    protected void onDestroy() {
        viewModel.destroy();
        super.onDestroy();
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i(TAG, "onActivityResult");
        if (requestCode == BLEPresenter.REQUEST_ENABLE_BT) {  //开启蓝牙的请求
            if (resultCode == Activity.RESULT_OK) {    //开启蓝牙请求成功
                Log.i(TAG, "bluetooth open success");
            } else {                                     //开启蓝牙请求失败
                Log.i(TAG, "refuse open bluetooth");
                viewModel.setRefuseOpenBlue();            //授权失败需要通知到SDK
            }
        }
    }

    private AlertDialog dialog1;
    private AlertDialog dialog2;
    public void setAndShowDialDialog(final int flag) {
        if (flag == 1) {
//            if (dialog1 == null) {
                dialog1 = new AlertDialog.Builder(this)
                        .setMessage("总里程:" + viewModel.totalMileage)
                        //相当于点击确认按钮
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (dialog != null) {
                                    dialog.cancel();
                                    viewModel.showPickCarDialog.set(false);
                                }
                            }
                        })
                        .create();
                dialog1.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        viewModel.showPickCarDialog.set(false);
                    }
                });
//            }
            dialog1.show();
        }else {
//            if (dialog2 == null) {
                dialog2 = new AlertDialog.Builder(this)
                        .setMessage("总里程:" + viewModel.totalMileage + "\ngps里程:" + viewModel.gpsMileage)
                        //相当于点击确认按钮
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (dialog != null) {
                                    dialog.cancel();
                                    viewModel.showReturnCarDialog.set(false);
                                }
                            }
                        })
                        .create();
                dialog2.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                        viewModel.showReturnCarDialog.set(false);
                    }
                });
//            }
            dialog2.show();
        }
    }
}
