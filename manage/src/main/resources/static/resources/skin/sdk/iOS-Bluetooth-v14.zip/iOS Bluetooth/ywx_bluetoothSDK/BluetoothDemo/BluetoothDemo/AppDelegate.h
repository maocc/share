//
//  AppDelegate.h
//  BluetoothDemo
//
//  Created by pengbingxiang on 2017/8/17.
//  Copyright © 2017年 yiweixing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

