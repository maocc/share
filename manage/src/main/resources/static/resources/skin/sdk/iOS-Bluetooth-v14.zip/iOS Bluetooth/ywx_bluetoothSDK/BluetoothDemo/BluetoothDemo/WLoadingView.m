//
//  WLoadingView.m
//  WeRentCar
//
//  Created by yiluda on 15/7/23.
//  Copyright (c) 2015年 weizuche. All rights reserved.
//

#import "WLoadingView.h"



@interface WLoadingView () {
    
    UIView *_backGView;
}

@end

@implementation WLoadingView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
    }
    
    return self;
}

- (void)createUI {

    _backGView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    _backGView.backgroundColor = [UIColor clearColor];
    [self addSubview:_backGView];
    
    CGFloat moreHeight = 0.0;
    CGFloat moreHeight2 = 0.0;
    if (self.frame.size.height < [UIScreen mainScreen].bounds.size.height) {
        moreHeight = 64;
    } else {
        moreHeight2 = 64*2;
    }
    _backGView.frame = CGRectMake(0, -moreHeight, self.frame.size.width, self.frame.size.height-moreHeight2);
    
    [self showHUDWithTitile:self.loadingText];
    
    [self addObserver:self forKeyPath:@"loadingText" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"loadingText"]) {
        
        self._hud.labelText = self.loadingText;
        
    }
    
    [self removeObserver:self forKeyPath:@"loadingText" context:nil];
}

- (void)showHUDWithTitile:(NSString *)title{
    
    if (!self._hud) {
        self._hud = [[MBProgressHUD alloc] initWithView:_backGView];
        
        [_backGView addSubview:self._hud];
    }
    self._hud.opacity = 0.5f;
    self._hud.labelText = title;
    [self._hud show:YES];
}

- (void)hideHUD{
    
    [self._hud hide:YES];
}

- (void)removeLoadingView {
    [self._hud hide:YES];
    [self._hud removeFromSuperview];
    self._hud = nil;
    [_backGView removeFromSuperview];
    _backGView = nil;
    [self removeFromSuperview];
}

@end
