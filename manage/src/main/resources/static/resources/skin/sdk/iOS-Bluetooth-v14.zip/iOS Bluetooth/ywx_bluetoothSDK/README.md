#### 用途：
提供给B端企业用于通过蓝牙控制微租车车机设备,用于集成到iOS端做app开发 支持车机1.0、2.0的低功耗蓝牙连接

#### 配置：
1.把SDK：BluetoothFramework.framework加入到工程中

2.设置Target --> Build Settings --> Linking --> Other Linker Flags,添加-ObjC

3.设置Target --> Build Settings --> Allow Non-modular Includes In Framework Modules为YES

#### 使用：
1.引用头文件

```
#import <BluetoothFramework/BluetoothFramework.h>
```
2.连接蓝牙设备（车机蓝牙模块）前需要中心模式初始化（==必须==）

```
// 1.蓝牙中心模式初始化
[[BluetoothManager standardBluetooth] bluetoothCentralManagerInit];
```
3.设置BluetoothManager的代理，代理遵守BluetoothManagerDelegate协议。
==代理必须设置，主设备（手机）连接蓝牙状态改变、蓝牙设备断开连接、命令发送成功失败的回调全部都在代理方法中。==

```
[BluetoothManager standardBluetooth].delegate = self;
```
4.蓝牙中心模式初始化后会检测主设备蓝牙状态，可在代理方法中对主设备蓝牙的不同状态做相应的处理

```
- (void)bluetoothCentralManagerDidUpdateState:(CBCentralManager *)central {
switch (central.state) {
case CBCentralManagerStateUnknown:
// 初始的时候是未知的（刚刚创建的时候）
NSLog(@">>>CBCentralManagerStateUnknown");
break;
case CBCentralManagerStateResetting:
//正在重置状态
NSLog(@">>>CBCentralManagerStateResetting");
break;
case CBCentralManagerStateUnsupported:
//设备不支持的状态
NSLog(@">>>CBCentralManagerStateUnsupported");
break;
case CBCentralManagerStateUnauthorized:
// 设备未授权状态
NSLog(@">>>CBCentralManagerStateUnauthorized");
break;
case CBCentralManagerStatePoweredOff:
//设备关闭状态
NSLog(@">>>CBCentralManagerStatePoweredOff");
break;
case CBCentralManagerStatePoweredOn:
// 设备开启状态 -- 可用状态
break;
default:
break;
}
}
```
5.主设备蓝牙状态是CBCentralManagerStatePoweredOn的时候可用，可以进行蓝牙连接\
连接前需要设置蓝牙设备的版本号：车机1.0的蓝牙模块对应BluetoothDeviceVersion1；车机2.0的蓝牙模块需要对应BluetoothDeviceVersion2

```
typedef NS_ENUM(NSInteger, BluetoothDeviceVersion) {
BluetoothDeviceVersion1,  // 车机1.0
BluetoothDeviceVersion2   // 车机2.0
};
```

```
[BluetoothManager standardBluetooth].bluetoothDeviceVersion = BluetoothDeviceVersion1;
```
6.扫描并连接蓝牙设备

```
/* YWX
* 扫描并连接蓝牙设备
* @param  macAddress      通过Mac地址连接蓝牙
* @param  pinCode         通过授权码建立通信
* @param  securityCode    通过加密秘钥进行安全通信
* @param  timeout         连接超时时间
* @param  connectSuccess  蓝牙连接成功并成功获取到特征的回调
* @param  connectFailure  蓝牙连接失败的回调
*/
- (void)connectPeripheralsWithMacAdress:(NSString*)macAddress
PinCode:(NSString*)pinCode
SecurityCode:(NSString*)securityCode
Timeout:(CGFloat)timeout
ConnectSuccess:(BluetoothConnectSuccess)connectSuccess
ConnectFailure:(BluetoothConnectFailure)connectFailure;
```
连接成功并获取通信的特征会返回connectSuccess结果，如果失败会返回失败原因connectFailure，相应的处理可以写在block中。

7.蓝牙发送命令

```
/* YWX
* 蓝牙发送命令
* @param  command  蓝牙控制命令
* @param  timeout  蓝牙控制命令超时时间
*/
- (BOOL)bluetoothWriteCommand:(BluetoothCommand)command
Timeout:(CGFloat)timeout;
```

命令有7中：

```
typedef NS_ENUM(NSInteger, BluetoothCommand) {
BluetoothCommandNone,     // 无命令
BluetoothCommandOpen,     // 开门
BluetoothCommandClose,    // 关门
BluetoothCommandSupply,   // 供电
BluetoothCommandBlackout  // 断电
BluetoothCommandPickCar,   // 取车
BluetoothCommandReturnCar  // 还车
BluetoothCommandInitialize,  // 初始化 1.0设备暂不支持
};
```
8.蓝牙断开连接

```
/* YWX
* 断开蓝牙连接 
*/
- (void)dismissConentedPeripheral;
```
蓝牙断开连接可以在代理方法中做处理

```
/* YWX
* 蓝牙设备断开连接 
* @param  peripheral  连接的蓝牙外设
*/
- (void)bluetoothManageDidDisconnectPeripheral:(CBPeripheral*)peripheral;
```
9.蓝牙重新连接，假如蓝牙断开连接可以使用这个方法重连蓝牙

```
/* YWX
* 蓝牙重新连接 
*/
- (void)reconnectPeripheral;
```
10.手机和蓝牙设备的通信可以通过设置是否管理员模式来进行限制，非管理员只能开关车门\
==对于C端客户要设置成非管理员模式，供电、断电只能让管理员使用==

```
/** 设置是否管理员模式，管理员模式可控制蓝牙4种命令，否则只能控制开关车门，默认不是管理员 **/
@property (nonatomic, assign) BOOL isAdminMode;
```
11.开关车门、供电、断电、初始化的回调
```
- (void)bluetoothManageDidUpdataResultCommandPeripheral:(BOOL)bl result:(NSString*)resultStr;
```
12.取还车的回调
```
- (void)bluetoothManageDidUpdataResultPickAndReturnCar:(BOOL)bl result:(NSDictionary*)dic;
```

#### 注意：
1.该BluetoothManager蓝牙管理类使用了单例创建\
2.蓝牙设备与手机进行连接，距离不能超过10米，否则会连接不上
