//
//  BluetoothManager.h
//  BluetoothDemo
//
//  Created by ywx on 2017/8/17.
//  Copyright © 2017年 yiweixing. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

#import <CoreBluetooth/CoreBluetooth.h>

#import "WBTError.h"

//@class WBTError;

typedef NS_ENUM(NSInteger, BluetoothDeviceVersion) {
    BluetoothDeviceVersion1,  // 车机1.0
    BluetoothDeviceVersion2   // 车机2.0
};

typedef NS_ENUM(NSInteger, BluetoothCommand) {
    BluetoothCommandNone,     // 无命令
    BluetoothCommandOpen,     // 开门
    BluetoothCommandClose,    // 关门
    BluetoothCommandSupply,   // 供电
    BluetoothCommandBlackout,  // 断电
    BluetoothCommandInitialize,  // 初始化 1.0设备暂不支持
    BluetoothCommandPickCar,     // 取车
    BluetoothCommandReturnCar    // 还车
};

typedef void(^BluetoothConnectSuccess)(CBPeripheral *peripheral);

typedef void(^BluetoothConnectFailure)(WBTError* error);

@protocol BluetoothManagerDelegate;

@interface BluetoothManager : NSObject

/** 蓝牙中心模式 */
@property (nonatomic, strong) CBCentralManager *centralManager;

/** 主设备蓝牙的状态 */
@property (nonatomic, assign) CBManagerState bluetoothState;

/** WBluetoothObject的代理 */
@property (nonatomic, weak) id<BluetoothManagerDelegate> delegate;

/** 判断是否连接到设备 */
@property (nonatomic, assign, readonly) BOOL isConnectPeripheral;

/** 设置是否管理员模式，默认不是管理员 **/
@property (nonatomic, assign) BOOL isAdminMode;

/** 调试模式 */
@property (nonatomic, assign) BOOL isDebugMode;

/** 车机设备的硬件版本,必须设置，默认是BluetoothDeviceVersion1 */
@property (nonatomic, assign) BluetoothDeviceVersion bluetoothDeviceVersion;

/* YWX
 * 单利初始化
 */
+ (BluetoothManager*)standardBluetooth;

/* YWX
 * 蓝牙中心模式初始化 ,必须先初始化
 */
- (void)bluetoothCentralManagerInit;

/* YWX
 * 扫描并配对蓝牙设备
 * @param  macAddress      通过Mac地址连接蓝牙
 * @param  pinCode         通过授权码建立通信
 * @param  securityCode    通过加密秘钥进行安全通信
 * @param  timeout         连接超时时间
 * @param  connectSuccess  蓝牙连接成功并成功获取到特征的回调
 * @param  connectFailure  蓝牙连接失败的回调
 */
- (void)connectPeripheralsWithMacAdress:(NSString*)macAddress
                                PinCode:(NSString*)pinCode
                           SecurityCode:(NSString*)securityCode
                                Timeout:(CGFloat)timeout
                         ConnectSuccess:(BluetoothConnectSuccess)connectSuccess
                         ConnectFailure:(BluetoothConnectFailure)connectFailure;

/* YWX
 * 蓝牙发送命令
 * @param  command  蓝牙控制命令
 * @param  timeout  蓝牙控制命令超时时间
 */
- (BOOL)bluetoothWriteCommand:(BluetoothCommand)command
                      Timeout:(CGFloat)timeout;

/* YWX
 * 蓝牙重新连接
 */
- (void)reconnectPeripheral;

/* YWX
 * 断开蓝牙连接
 */
- (void)dismissConentedPeripheral;

@end

//********************** WBluetoothObject的代理方法 *************************

@protocol BluetoothManagerDelegate <NSObject>

@optional

/* YWX
 * 主设备状态改变的委托，在初始化CBCentralManager的时候会打开设备，只有当设备正确打开后才能使用
 * @param  central  蓝牙中心模式
 */
- (void)bluetoothCentralManagerDidUpdateState:(CBCentralManager *)central;

/* YWX
 * 蓝牙设备断开连接
 * @param  peripheral  连接的蓝牙外设
 */
- (void)bluetoothManageDidDisconnectPeripheral:(CBPeripheral*)peripheral;

/* YWX
 * 开关车门、供电、断电、初始化的回调
 * @param  bl          命令是否发送成功
 * @param  resultStr   返回的结果
 */
- (void)bluetoothManageDidUpdataResultCommandPeripheral:(BOOL)bl result:(NSString*)resultStr;

/* YWX
 * 取还车的回调
 * @param  bl          命令是否发送成功
 * @param  resultStr   返回的结果
 */
- (void)bluetoothManageDidUpdataResultPickAndReturnCar:(BOOL)bl result:(NSDictionary*)dic;



@end







