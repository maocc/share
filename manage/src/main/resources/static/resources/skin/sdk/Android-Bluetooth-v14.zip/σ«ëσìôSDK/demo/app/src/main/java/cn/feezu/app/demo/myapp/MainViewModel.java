package cn.feezu.app.demo.myapp;

import android.app.Activity;
import android.databinding.BaseObservable;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import cn.feezu.ble_control.BLEPresenter;
import cn.feezu.ble_control.event.BLEEvent;
import cn.feezu.ble_control.state.BLUETOOTH_ENABLE;
import cn.feezu.ble_control.state.BL_CONNECT_STATE;
import cn.feezu.ble_control.state.ControlType;

import static cn.feezu.ble_control.state.ControlType.PICK_CAR;
import static cn.feezu.ble_control.state.ControlType.RETURN_CAR;

/**
 * cn.feezu.app.demo.myapp
 * wangxn
 * 2017/8/18
 */

public class MainViewModel extends BaseObservable {

    private static final String TAG = "MainViewModel";
    private final Activity mActivity;

    public ObservableField<String> mMacAddress = new ObservableField<>();
    public ObservableField<String> mDeviceVersion = new ObservableField<>();
    public ObservableField<String> mIsClient = new ObservableField<>();
    public ObservableField<String> mToken = new ObservableField<>();
    public ObservableField<String> mkey = new ObservableField<>();
    public ObservableField<Boolean> btnEnabled = new ObservableField<>();
    private BLEPresenter instance;

    public ObservableField<String> setScanTime = new ObservableField<>("5");
    public ObservableField<String> setTotalTime = new ObservableField<>("20");

    public ObservableField<String> connectStatusTxt = new ObservableField<>();

    public MainViewModel(Activity activity) {
        EventBus.getDefault().register(this);
        mMacAddress.set("C4BE8414A9DE");
        mDeviceVersion.set("1.0");
        mIsClient.set("2");
        mToken.set("858737");
        mkey.set("1781462576239334");//秘钥格式
        this.mActivity = activity;
        btnEnabled.set(true);
    }

    private String mac;

    private String deviceVersion;

    private boolean isClient;

    private String token;

    private String key;

    public void macChanged(Editable editable) {
        if (editable != null && editable.length() > 0) {
            mac = editable.toString();
        }
    }

    public void deviceVersionChanged(Editable editable) {
        if (editable != null && editable.length() > 0) {
            deviceVersion = editable.toString();
        }
    }

    public void isClientChanged(Editable editable) {
        if (editable != null && editable.length() > 0) {
            if ("1".equals(editable.toString())) {
                isClient = true;
            } else {
                isClient = false;
            }
        }
    }

    public void tokenChanged(Editable editable) {
        if (editable != null && editable.length() > 0) {
            token = editable.toString();
        }
    }

    public void keyChanged(Editable editable) {
        if (editable != null && editable.length() > 0) {
            key = editable.toString();
        }
    }

    public void opendoor(){
        retryCount = 0;
        lastControlType = ControlType.OPEN_DOOR;
        connect(ControlType.OPEN_DOOR);
    }

    public void closedoor(){
        retryCount = 0;
        lastControlType = ControlType.CLOSE_DOOR;
        connect(ControlType.CLOSE_DOOR);
    }

    public void power(){
        retryCount = 0;
        lastControlType = ControlType.POWER;
        connect(ControlType.POWER);
    }

    public void dispower(){
        retryCount = 0;
        lastControlType = ControlType.DISPOWER;
        connect(ControlType.DISPOWER);
    }

    public void init(){
        retryCount = 0;
        lastControlType = ControlType.INIT;
        connect(ControlType.INIT);
    }

    public void pickCar(View view){
        retryCount = 0;
        lastControlType = PICK_CAR;
        connect(PICK_CAR);
    }

    public void returnCar(View view){
        retryCount = 0;
        lastControlType = ControlType.RETURN_CAR;
        connect(ControlType.RETURN_CAR);
    }

    private boolean theIsClient;

    private String theDeviceVersion;

    private String theMac;

    private String theToken;

    private String theKey;


    public void connect(@ControlType.Type int controlType) {
        Log.i(TAG, "mac : " + mac + ", theMac =" + theMac);
        Log.i(TAG, "deviceVersion : " + deviceVersion + ", theDeviceVersion = " + theDeviceVersion);
        Log.i(TAG, "isClient : " + isClient + ", theIsClient = " + theIsClient);
        Log.i(TAG, "token : " + token + ", theToken = " + theToken);
        Log.i(TAG, "key : " + key + ", theToken = " + theKey);

        if (instance == null) {
            Log.i(TAG, "instance is null");
            createInstance();
        }else {
            if (!mac.equals(theMac)
                    || !(isClient == theIsClient)
                    || !deviceVersion.equals(theDeviceVersion)
                    || !token.equals(theToken)
                    || !key.equals(theKey)){
                Log.i(TAG, "arguments changed");
                createInstance();
            }
        }

        instance.setHasSendFinishEvent();
        Log.i(TAG, "openBle");
        if(instance.openBle(controlType)){
            btnEnabled.set(false);
        }else {
            instance.init();
        }
    }

    private void createInstance() {
        Log.i(TAG, "createInstance");
        if (instance != null){
            Log.i(TAG, "createInstance destory instance");
            instance.destroy();
            instance = null;
        }
        theIsClient = isClient;
        theDeviceVersion = deviceVersion;
        theMac = mac;
        theToken = token;
        theKey = key;
        instance = BLEPresenter.getInstance(isClient, deviceVersion, mac, token, key, mActivity);
        instance.init();
    }

    /**
     * 上一次操作的类型
     */
    private int lastControlType;

    private int retryCount;

    public ObservableBoolean showPickCarDialog = new ObservableBoolean(false);
    public ObservableBoolean showReturnCarDialog = new ObservableBoolean(false);

    public double totalMileage;

    public double gpsMileage;

    /**
     * 结束
     * @param bean
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onBLEEvent(BLEEvent.ControlResponseBean bean) {
        Log.d(TAG, "response : " + bean.isStatus() + ", " + bean.getMsg() + ", " + bean.getCode());
        if(bean.getCode() != -3 && bean.getCode() != -4) {
            btnEnabled.set(true);
            if (bean.getCode() == -2) {
                retryCount++;
                if (isCanRetry) {
                    if (retryCount <= 3) {
                        Log.d(TAG, "重试次数,retry=" + retryCount);
                        connect(lastControlType);
                        return;
                    }
                }
            }
        }
        Toast.makeText(mActivity, bean.getMsg(), Toast.LENGTH_SHORT).show();

        if (lastControlType == PICK_CAR) {
            if(bean.getCarInfo() != null){
                totalMileage = bean.getCarInfo().getTotalMileage();
                Toast.makeText(mActivity, "totalMileage:" + totalMileage, Toast.LENGTH_LONG).show();
                showPickCarDialog.set(true);
            }
        } else if (lastControlType == RETURN_CAR) {
            if(bean.getCarInfo() != null){
                totalMileage = bean.getCarInfo().getTotalMileage();
                gpsMileage = bean.getCarInfo().getGpsMileage();
                Toast.makeText(mActivity, "totalMileage:" + totalMileage + ",gpsMileage:" + gpsMileage, Toast.LENGTH_LONG).show();
                showReturnCarDialog.set(true);
            }
        }

        switch (instance.isConnected()) {
            case STATE_CONNECTED:
                connectStatusTxt.set("已连接");
                break;
            case STATE_CONNECTING:
                connectStatusTxt.set("连接中..");
                break;
            case STATE_DISCONNECTED:
                connectStatusTxt.set("未连接..");
                break;
            case STATE_LISTENING:
                connectStatusTxt.set("监听中..");
                break;
            case STATE_DISCOVER_SERVICES:
                connectStatusTxt.set("发现服务..");
                break;
            default:
                connectStatusTxt.set("未连接..");
        }
    }

    public void destroy() {
        EventBus.getDefault().unregister(this);
        Log.i(TAG, "destroy");
        if (instance != null) {
            instance.destroy();                           //SDK 销毁的方法
        }
    }

    public void resume() {}

    public void setRefuseOpenBlue() {
        if(instance != null) {
            instance.setIsBleOpen(BLUETOOTH_ENABLE.UNABLE);  //通知SDK 用户选择不开启蓝牙
        }
    }

    public void setTotalTime(View view) {
        Log.i(TAG, "totalTime:" + setTotalTime.get());
        if (instance != null) {
            instance.setTimeout(Integer.parseInt(setTotalTime.get()) * 1000);
        }else {
            Log.d(TAG, "没有instance对象初始化");
            createInstance();
            instance.setTimeout(Integer.parseInt(setTotalTime.get()) * 1000);
        }
    }

    public void setScanTime(View view) {
        Log.i(TAG, "scanTime : " + setScanTime.get());
        if (instance != null) {
            instance.setScanTimeout(Integer.parseInt(setScanTime.get()) * 1000);
        }else {
            Log.d(TAG, "没有instance对象初始化");
            createInstance();
            instance.setScanTimeout(Integer.parseInt(setScanTime.get()) * 1000);
        }
    }

    public void disconnect(View view){
        if (instance != null) {
            instance.cancelConnect();
        }
        isConnect = false;
    }

    public boolean isConnect = false;

    public void justconnect(View view){
        retryCount = 0;
        lastControlType = ControlType.CONNECT;
        connect(ControlType.CONNECT);
    }

    private boolean isCanRetry = false;

    public void checkedChange(View view, boolean isChecked) {
        if (isChecked) {
            if (view.getId() == R.id.rb_1) {
                Log.d(TAG, "R.id.rb_1");
                isCanRetry = true;
            } else if (view.getId() == R.id.rb_2) {
                Log.d(TAG, "R.id.rb_2");
                isCanRetry = false;
            }
        }
        Log.d(TAG, "checkedChange");
    }

}

