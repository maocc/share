//
//  ViewController.m
//  BluetoothDemo
//
//  Created by pengbingxiang on 2017/8/17.
//  Copyright © 2017年 yiweixing. All rights reserved.
//

#import "ViewController.h"
#import "WLoadingView.h"
#import <WZCBluetooth/WZCBluetooth.h>

@interface ViewController ()<BluetoothManagerDelegate>
{
    BluetoothCommand _command;
}
@property(nonatomic, strong)WLoadingView *loading;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    [self test];
    
}

- (void)test {
    UITextField *textField1 = (UITextField*)[self.view viewWithTag:300];
    UITextField *textField2 = (UITextField*)[self.view viewWithTag:301];
    UITextField *textField3 = (UITextField*)[self.view viewWithTag:302];
    UITextField *textField4 = (UITextField*)[self.view viewWithTag:303];
    UITextField *textField5 = (UITextField*)[self.view viewWithTag:304];
    
    textField1.text = @"2.0";
    textField2.text = @"881b991105bb";
    textField3.text = @"73412386";
    textField4.text = @"0";
    textField5.text = @"76GWNGK6D2DRACR1";
}
- (void)createUI {
    // 选择页
    UIView *selectView = [[UIView alloc]initWithFrame:CGRectMake(0, 60, self.view.frame.size.width, 400)];
    [self.view addSubview:selectView];
    NSArray *arr1 = @[@"设备版本：",@"Mac地址：",@"授权码",@"管理员",@"秘钥："];
    NSArray *arr2 = @[@"输入设备版本",@"输入Mac地址",@"输入授权码",@"是否管理员(0/1)",@"输入秘钥"];
    for (int i=0; i<5; i++) {
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(14, 10 + i*40, 120, 30)];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentLeft;
        label.font = [UIFont systemFontOfSize:18];
        label.text = arr1[i];
        [selectView addSubview:label];
        //
        UITextField *authCodeTextField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) + 10, CGRectGetMinY(label.frame), 200, 30)];
        authCodeTextField.textAlignment = NSTextAlignmentLeft;
        authCodeTextField.clearButtonMode = YES;
        authCodeTextField.font = [UIFont systemFontOfSize:18];
        authCodeTextField.textColor = [UIColor grayColor];
        authCodeTextField.placeholder = arr2[i];
        authCodeTextField.tag = 300 + i;
        [selectView addSubview:authCodeTextField];
    }
    
    // 车辆控制页
    UIView *controlView = [[UIView alloc]initWithFrame:CGRectMake(0, 270*self.view.frame.size.width/320, self.view.frame.size.width, 400)];
    [self.view addSubview:controlView];
    NSArray *titleArr = @[@"连接",@"断开",@"开门",@"关门",@"供电",@"断电",@"取车",@"还车",@"初始化"];
    for (int i=0; i<titleArr.count; i++) {
        
        UIButton*button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(20 + (i % 2) * 120, (i / 2) * 60, 100, 50);
        // button的title
        [button setTitle:titleArr[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        // 设置背景颜色
        button.backgroundColor = [UIColor orangeColor];
        // 点击事件
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = 100 + i;
        [controlView addSubview:button];
    }
}

- (void)buttonClick:(UIButton*)button {
    
    if (button.tag == 100) {
        // 蓝牙连接
        [self bluetoothInit];
    } else if (button.tag == 101) {
        // 蓝牙断开连接
        [[BluetoothManager standardBluetooth] dismissConentedPeripheral];
//        NSLog(@"%zd -- ",[BluetoothManager standardBluetooth].isConnectPeripheral);
    } else if (button.tag == 102) {
        // 开门
        [self command:BluetoothCommandOpen];
    } else if (button.tag == 103) {
        // 关门
        [self command:BluetoothCommandClose];
    } else if (button.tag == 104) {
        // 供电
        [self command:BluetoothCommandSupply];
    } else if (button.tag == 105) {
        // 断电
        [self command:BluetoothCommandBlackout];
    } else if (button.tag == 106) {
        // 取车
        [self command:BluetoothCommandPickCar];
    } else if (button.tag == 107) {
        // 还车
        [self command:BluetoothCommandReturnCar];
    } else if (button.tag == 108) {
        // 初始化
        [self command:BluetoothCommandInitialize];
    }
}
- (void)bluetoothInit {
    NSLog(@"-----bluetoothInit start----");
    NSLog(@"bluetoothConnect --- ");
    // 1.蓝牙中心模式初始化
    [[BluetoothManager standardBluetooth] bluetoothCentralManagerInit];
    [BluetoothManager standardBluetooth].delegate = self;
    [BluetoothManager standardBluetooth].isDebugMode = YES;
    UITextField *textField1 = (UITextField*)[self.view viewWithTag:300];
    UITextField *textField2 = (UITextField*)[self.view viewWithTag:303];
    if ([@"1.0" isEqualToString:textField1.text]) {
        [BluetoothManager standardBluetooth].bluetoothDeviceVersion = BluetoothDeviceVersion1;
    } else {
        [BluetoothManager standardBluetooth].bluetoothDeviceVersion = BluetoothDeviceVersion2;
    }
    if ([@"1" isEqualToString:textField2.text]) {
        [BluetoothManager standardBluetooth].isAdminMode = YES;
    } else {
        [BluetoothManager standardBluetooth].isAdminMode = NO;
    }
    NSLog(@"-----bluetoothInit end----");
}
- (void)command:(BluetoothCommand)command {
    if (![BluetoothManager standardBluetooth].isConnectPeripheral) {
        [self bluetoothInit];
        _command = command;
    } else {
        [self writeCommand:command];
    }
}
- (void)writeCommand:(BluetoothCommand)command {
    _command = BluetoothCommandNone;
    if (command == BluetoothCommandOpen) {
        [self createLoadingWithTitle:@"正在开门..."];
    } else if (command == BluetoothCommandClose) {
        [self createLoadingWithTitle:@"正在关门..."];
    } else if (command == BluetoothCommandSupply) {
        [self createLoadingWithTitle:@"正在供电..."];
    } else if (command == BluetoothCommandBlackout) {
        [self createLoadingWithTitle:@"正在断电..."];
    } else if (command == BluetoothCommandPickCar) {
        [self createLoadingWithTitle:@"正在取车..."];
    } else if (command == BluetoothCommandReturnCar) {
        [self createLoadingWithTitle:@"正在还车..."];
    } else {
        [self createLoadingWithTitle:@"正在初始化..."];
    }
    
    [[BluetoothManager standardBluetooth] bluetoothWriteCommand:command Timeout:10];
}
#pragma mark - 蓝牙代理方法
- (void)bluetoothCentralManagerDidUpdateState:(CBCentralManager *)central {
    NSLog(@"bluetoothCentralManagerDidUpdateState --- %@",[NSThread currentThread]);
    switch (central.state) {
        case CBCentralManagerStateUnknown:
            // 初始的时候是未知的（刚刚创建的时候）
            NSLog(@">>>CBCentralManagerStateUnknown");
            break;
        case CBCentralManagerStateResetting:
            //正在重置状态
            NSLog(@">>>CBCentralManagerStateResetting");
            break;
        case CBCentralManagerStateUnsupported:
            //设备不支持的状态
            NSLog(@">>>CBCentralManagerStateUnsupported");
            break;
        case CBCentralManagerStateUnauthorized:
            // 设备未授权状态
            NSLog(@">>>CBCentralManagerStateUnauthorized");
            break;
        case CBCentralManagerStatePoweredOff:
        {
            //设备关闭状态
            NSLog(@">>>CBCentralManagerStatePoweredOff");
            [self alertViewControllerWithTitle:nil message:@"信号不佳可使用蓝牙进行极速开关车门，是否开启蓝牙" defaultTitle:@"是" handler:^(UIAlertAction *action) {
                // 跳转到蓝牙设置界面
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"App-Prefs:root=Bluetooth"]];
            } cancelTitle:@"否" handler:^(UIAlertAction *action) {
                // 无操作
            }];
        }
            break;
        case CBCentralManagerStatePoweredOn:
        {
            // 设备开启状态 -- 可用状态
            NSLog(@">>>CBCentralManagerStatePoweredOn");
//            NSLog(@" ---- %zd",[BluetoothManager standardBluetooth].isConnectPeripheral);
            // 搜索设备
            [self bluetoothConnect];
        }
            break;
        default:
            break;
    }
    NSLog(@"bluetoothCentralManagerDidUpdateState --- end");
}
- (void)bluetoothConnect {
    UITextField *textField1 = (UITextField*)[self.view viewWithTag:300];
    UITextField *textField2 = (UITextField*)[self.view viewWithTag:301];
    UITextField *textField3 = (UITextField*)[self.view viewWithTag:302];
    UITextField *textField4 = (UITextField*)[self.view viewWithTag:304];
    NSLog(@"%@ --- %@ --- %@",textField1.text,textField2.text,textField3.text);
    [self createLoadingWithTitle:@"正在连接..."];
    [[BluetoothManager standardBluetooth] connectPeripheralsWithMacAdress:textField2.text PinCode:textField3.text SecurityCode:textField4.text Timeout:10 ConnectSuccess:^(CBPeripheral *peripheral) {
        NSLog(@" --- success --- %@",[NSThread currentThread]);
//        NSLog(@" ---- %zd",[BluetoothManager standardBluetooth].isConnectPeripheral);
        NSLog(@"peripheral -- %@",peripheral);
        [self removeLoading];
        if (_command == BluetoothCommandNone) {
            [self alertViewControllerWithTitle:@"温馨提示" message:@"连接成功" defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
        } else {
            [self command:_command];
        }
        
    } ConnectFailure:^(WBTError* error) {
        NSLog(@" --- failure --- %@",[NSThread currentThread]);
//        NSLog(@" ---- %zd",[BluetoothManager standardBluetooth].isConnectPeripheral);
        NSLog(@"error -- %@",error);
//        NSLog(@"%zd -- %@ -- %@",error.code,[error.userInfo objectForKey:WBTDescriptionKey],error.userInfo);
        [self removeLoading];
        [self alertViewControllerWithTitle:[error.userInfo objectForKey:WBTDescriptionKey] message:[error.userInfo objectForKey:WBTFailureReasonKey] defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
    }];
}

// 开关车门的回调
- (void)bluetoothManageDidUpdataResultCommandPeripheral:(BOOL)bl result:(NSString *)resultStr {
//    NSLog(@" -- bl = %zd -- result = %@ -- ",bl,resultStr);
    [self removeLoading];
    [self alertViewControllerWithTitle:@"温馨提示" message:resultStr defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
}
// 取车、还车的回调
- (void)bluetoothManageDidUpdataResultPickAndReturnCar:(BOOL)bl result:(NSDictionary*)dic{
    [self removeLoading];
    // 取车
    if ([@"01" isEqualToString:dic[@"type"]]) {
        NSString *tipStr = [NSString stringWithFormat:@"%@,OBDMileage==%@km",dic[@"message"],dic[@"OBDMileage"]];
        [self alertViewControllerWithTitle:@"温馨提示" message:tipStr defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
    } else{ // 还车
        NSString *tipStr = [NSString stringWithFormat:@"%@,totalMileage==%@m,OBDMileage==%@km",dic[@"message"],dic[@"totalMileage"],dic[@"OBDMileage"]];
        [self alertViewControllerWithTitle:@"温馨提示" message:tipStr defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
    }
}
- (void)bluetoothManageDidDisconnectPeripheral:(CBPeripheral *)peripheral {
    NSLog(@" ---- 连接断开 ---- ");
    
    [self alertViewControllerWithTitle:@"温馨提示" message:@"蓝牙断开连接" defaultTitle:@"确定" handler:nil cancelTitle:nil handler:nil];
}
#pragma mark - 自定义alertViewController
- (void)alertViewControllerWithTitle:(NSString*)titleStr message:(NSString*)messageStr defaultTitle:(NSString*)defaultTitleStr handler:(void (^ __nullable)(UIAlertAction *action))defaultAction cancelTitle:(NSString*)cancleTitleStr handler:(void (^ __nullable)(UIAlertAction *action))cancelAction {
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:titleStr message:messageStr preferredStyle:UIAlertControllerStyleAlert];
    if (defaultTitleStr) {
        [alertVc addAction:[UIAlertAction actionWithTitle:defaultTitleStr style:UIAlertActionStyleDefault handler:defaultAction]];
    }
    if (cancleTitleStr) {
        [alertVc addAction:[UIAlertAction actionWithTitle:cancleTitleStr style:UIAlertActionStyleCancel handler:cancelAction]];
    }
    [self presentViewController:alertVc animated:YES completion:nil];
}
#pragma mark - 创建去除加载界面
- (void)createLoadingWithTitle:(NSString *)titleString {
    
    if (!self.loading) {
        
        self.loading = [[WLoadingView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        self.loading.loadingText = titleString;
        [self.view addSubview:self.loading];
        
    } else {
        self.loading._hud.labelText = titleString;
    }
}
- (void)removeLoading {
    [self.loading removeLoadingView];
    self.loading = nil;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
