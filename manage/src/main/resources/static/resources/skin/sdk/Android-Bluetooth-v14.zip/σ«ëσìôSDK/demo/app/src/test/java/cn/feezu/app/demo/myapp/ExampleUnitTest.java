package cn.feezu.app.demo.myapp;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }

//    @Test
//    public void testAscii2hex() {
//        String a = "50N8QWD8A0J0VEGR";
//        boolean result = StrUtil.ascii2hex(a).equalsIgnoreCase("35304E385157443841304A3056454752");
//        Assert.assertTrue(result);
//    }
}