# 蓝牙控制SDK


### 版本信息
2017/08/21  version1

2017/09/01 version2 

- 增加数据加密

2018/01/24   version3 

- 增加扫描时间设置方法
- 断开连接方法
- 蓝牙连接状态
- 完善状态信息以及各种异常/回调 

2018/03/05 version4

- 增加创建连接的功能, 增加类型ControlType.CONNECT

2018/04/09 version5

- 修复SDK连接1.0版车机低功耗蓝牙时的稳定性问题,提高连接成功率

2018/04/13

- 修复SDK对车机2.0保持向下兼容

2018/05/14

- 增加车机2.0蓝牙方法可以初始化
- 增加了版本信息

2018/06/04 version7

- 车机1.0,用户模式下, 增加了蓝牙取车,还车功能
- 优化openBle()接口方法, ControlType的类型更改为int型, 增加注解限制类型ControlType.Type

2018/07/20 version8

- 车机2.0, 固定PIN码, 修复bug, 增强安全性

---

### 用途
提供给B端企业用于通过蓝牙控制微租车车机设备,用于集成到Android端做app开发
支持车机1.0上的低功耗蓝牙和车机2.0上的经典蓝牙连接

---

### android版本支持

<pre><code>
compileSdkVersion 26
buildToolsVersion "26.0.1"

minSdkVersion 18
targetSdkVersion 26
</code></pre>

### 需要用到的开源库

<pre><code>
compile 'com.android.support:appcompat-v7:26.+'
compile 'com.android.support:support-v4:26.+'
compile 'org.greenrobot:eventbus:3.0.0'
</code></pre>

---

### 接口类

cn.feezu.ble_control.BLEPresenter

### 接口方法

- 对象获取

<pre><code>
/**
 * 获取控制蓝牙的接口类
 * @param isAdminMode         true - 管理员使用,能操作开门关门断电供电  
 *                            false - 提供给C端用户使用, 可以操作开门关门;
 * @param deviceVersion       车机版本,  当前只支持1.0 和2.0版本
 * @param macAddress          蓝牙Mac地址, 去掉':'冒号,全部大写
 * @param pinCode             蓝牙通讯的安全码
 * @param securityCode        蓝牙通讯的加密秘钥, 十六进制格式
 * @param activity            当前界面activity,用于创建服务和广播接受者
 * @return                    蓝牙控制类
 */
public static BLEPresenter getInstance(boolean isAdminMode, String deviceVersion, String macAddress, String pinCode, String securityCode, Activity activity);
</code></pre>

- 初始化

<pre><code>
/**
 * 获取到BLEPresenter对象之后必须初始化,初始化一次, 在调用cancelConnect()方法之后也必须调用init()方法
 * 对于车机2.0上的经典蓝牙, init()方法必须在openBle()方法之前,且最好有一定的时间差, 以保证初始化服务的完全启动
 */
public void init();
</code></pre>

- 设置扫描的超时时间

<pre><code>
/**
 * 设置扫描的超时时间, 默认为5秒
 * @param millisec  毫秒单位
 */
public void setScanTimeout(int millisec)
</code></pre>

- 设置总的超时时间

<pre><code>
/**
 * 设置总的超时时间,包括扫描时间,建立连接时间,数据传输时间, 默认为20秒
 * @param millisec  毫秒单位
 */
public void setTimeout(int millisec)
</code></pre>

- 重置连接结束标志位

<pre><code>

/**
 * 重新设置结束标志位,在openBle()方法之前调用
 */
public void setHasSendFinishEvent();

</code></pre>

- 启动蓝牙连接控制数据传输

<pre><code>
/**
 * 开始操控蓝牙,启动蓝牙,开启扫描,建立连接,传输数据
 * @param type 设置车机操纵类型 取值 
 *          ControlType.OPEN_DOOR  : 开门
 *          ControlType.CLOSE_DOOR : 关门
 *          ControlType.POWER      : 供电, 管理员模式使用
 *          ControlType.DISPOWER   : 断电, 管理员模式使用
 *          ControlType.CONNECT    : 建立连接
 *          ControlType.INIT       : 初始化,目前只用于车机2.0上的蓝牙且必须是管理员模式下的使用
 *          ControlType.PICK_CAR   : 下单之后首次取车
 *          ControlType.RETURN_CAR :  完结订单时还车
 * @return  当前数据状态是否可以继续进行操作
 */
public boolean openBle(byte type);
</code></pre>

- 授权开启蓝牙时,通知蓝牙开启状态

<pre><code>
/**
 * 当启动蓝牙时,需要用户同意授权,如果用户拒绝,需要调用这个方法通知BLEPresenter对象状态
 * @param enabling 设置是否蓝牙被开启或者关闭, 取值: BLUETOOTH_ENABLE
 */
public void setIsBleOpen(BLUETOOTH_ENABLE enabling)
</code></pre>

- 连接状态

<pre><code>
/**
 * 返回enum:
 * BL_CONNECT_STATE.STATE_DISCONNECTED  连接断开
                   .STATE_CONNECTING    连接中
                   .STATE_CONNECTED     连接已经建立
 *
 */
public BL_CONNECT_STATE isConnected();
</code></pre>

- 断开连接

<pre><code>
/**
 * 断开连接
 * 调用本方法之后,如果需要重新建立连接, 需要重新调用init()方法
 * 车机2.0上使用的是经典蓝牙, 配对过程非常耗费资源
 * 断开连接会清理掉对蓝牙设备的绑定
 */
public void cancelConnect();
</code></pre>


- 销毁

<pre><code>
/**
 * 销毁方法
 */
public void destroy();
</code></pre>

### 弹窗提示用户开启蓝牙时, 用户未授权处理

<pre></code>
@Override
public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    Log.i(TAG, "onActivityResult");
    if (requestCode == BLEPresenter.REQUEST_ENABLE_BT) {  //开启蓝牙的请求的响应
        if (resultCode == Activity.RESULT_OK) {    //开启蓝牙请求成功
            Log.i(TAG, "bluetooth open success");
        } else {                                     //开启蓝牙请求失败
            Log.i(TAG, "refuse open bluetooth");
            blePresenter.setIsBleOpen(BLUETOOTH_ENABLE.UNABLE); //授权失败需要通知到SDK
        }
    }
}
</code></pre>

### 操作蓝牙的响应结果异步处理

aar包中集成了 EventBus3 ,处理结果响应 需要使用EventBus来处理

<pre><code>
/**
 * 蓝牙操作响应处理
 * @param bean ControlResponseBean有2个属性
                    status: true  -成功,
                            false -失败或者中间状态;  
                    msg: 响应消息
                    code: 状态码
 */
@Subscribe(threadMode = ThreadMode.MAIN)
public void onBLEEvent(BLEEvent.ControlResponseBean bean) {
    Log.d(TAG, "response : " + bean.isStatus() + ", " + bean.getMsg());
    Toast.makeText(mActivity, bean.getMsg(), Toast.LENGTH_SHORT).show();
    btnEnabled.set(true);
}
</code></pre>



### BLEEvent.ControlResponseBean 返回的错误/异常/回调

|回调编码|中文提示信息|详细解释|
| - | - | - |
| -99 | "当前设备不支持蓝牙"  | |
| -100 | "蓝牙关闭" | 手机开启蓝牙授权失败时的通知 |
| -101 | "蓝牙连接断开,请重试" | |
| --- | --- | --- |
| -90 | "没有连接标识" | 执行openBle()时,判断mToken为空  |
| -91 | "没有目标设备" |执行openBle()时,目标蓝牙mac地址为空 |
| -92 | "不支持的操作" | 执行openBle()判断是否是管理员身份,不是管理员身份不能执行供电/断电操作 |
| -93 | "操作类型不正确" | 执行openBle()时,操作类型为空 |
| -94 | "没有初始化" | 初始化时会创建一个广播接受者, 这里判断执行openBle()时广播是否存在 |
| -95 | "不要重复操作" | 执行openBle()时,上一次连接操作还没有结束 |
| --- | --- | --- |
|-2 | "连接超时" | 控制整个蓝牙扫描连接传输过程的超时 |
|-3 | "开始扫描" | 开始扫描蓝牙设备 **(这个是回调,不是连接失败)** |
|-4 | "找到蓝牙设备,开始连接/开始绑定" | 扫描结束, 找到了蓝牙设备  **(这个是回调,不是连接失败)** |
|-5 | "没有找到蓝牙设备,请重试" | 扫描结束, 没有找到目标蓝牙设置, 扫描超时 |
|-6  | "没有通过蓝牙设备验证" | 找不到了目标蓝牙,但是和蓝牙的绑定失败(经典蓝牙) |
| --- | --- | --- |
|-11 | "没有连接到蓝牙,请重试" | 传输数据时,发送了数据,但是没有接受到数据, 经典蓝牙|
|-12 | "数据处理没有成功,请重试." | 传输数据时,读取到了目标蓝牙响应数据,但是解析失败(经典蓝牙) |
|-13 | "无授权连接." | 当前授权码不能通过蓝牙连接 |
|-14 | "请输入正确格式和长度秘钥." | 传输数据时,检测到秘钥错误 |
|-15 | 其他 | 传输数据时, 解析数据异常|
